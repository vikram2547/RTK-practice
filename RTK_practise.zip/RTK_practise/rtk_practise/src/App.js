// src/App.js
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import Vikram from './components/Vikram';
import NewPage from './components/NewPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/vikram" />} />
        <Route path="/vikram" element={<Vikram />} />
        <Route path="/newPage" element={<NewPage/>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
