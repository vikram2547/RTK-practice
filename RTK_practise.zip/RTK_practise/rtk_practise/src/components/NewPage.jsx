// import React, { useState } from "react";

// function NewPage() {
//   const [name, setName] = useState("");
//   const [address, setAddress] = useState("");
//   const [users, setUsers] = useState([]);
//   const [editIndex, setEditIndex] = useState(null);

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     if (!name || !address) {
//       console.log("please fill the fields");
//       return;
//     } else if (editIndex !== null) {
//       const updateUser = [...users];
//       updateUser[editIndex] = { name, address };
//       setUsers(updateUser);
//       setEditIndex(null);
//     } else {
//       const newUser = { name, address };
//       setUsers([...users, newUser]);
//     }
//     setName("");
//     setAddress("");
//   };

//   const handleEdit = (index) => {
//     const userToEdit = users[index];
//     setName(userToEdit.name);
//     setAddress(userToEdit.address);
//     setEditIndex(index);
//   };

//   const handleDelete = (index) => {
//     const updateUser = [...users];
//     updateUser.splice(index, 1);
//     setUsers(updateUser);
//   };

//   return (
//     <>
//       <div>
//         <h1>login form</h1>
//         <form onSubmit={handleSubmit}>
//           <div>
//             <label htmlFor="name">Name</label>
//             <input
//               type="text"
//               id="name"
//               placeholder="enter your name"
//               value={name}
//               onChange={(e) => setName(e.target.value)}
//               required
//             />
//           </div>
//           <div>
//             <label>Address</label>
//             <input
//               type="text"
//               id="address"
//               placeholder="enter your address"
//               value={address}
//               onChange={(e) => setAddress(e.target.value)}
//               required
//             />
//           </div>
//           <button type="submit">{editIndex !== null ? "Update" : "Add"}</button>
//         </form>
//       </div>
//       <div>
//         <table>
//           <thead>
//             <tr>
//               <th>Name</th>
//               <th>Address</th>
//               <th>Action</th>
//             </tr>
//           </thead>
//           <tbody>
//             {users.map((user, index) => (
//               <tr key={index}>
//                 <td>{user.name}</td>
//                 <td>{user.address}</td>
//                 <td>
//                   <button onClick={() => handleEdit(index)}>Edit</button>
//                   <button onClick={() => handleDelete(index)}>Delete</button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>
//     </>
//   );
// }

// export default NewPage;
import React, { useState } from "react";

function NewPage() {
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [users, setUsers] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();

    if (!name || !address) {
      console.log("Please fill in both fields.");
      return;
    }

    if (editIndex !== null) {
      // Update existing user
      const updatedUsers = users.map((user, index) =>
        index === editIndex ? { name, address } : user
      );
      setUsers(updatedUsers);
      setEditIndex(null);
    } else {
      // Add new user
      const newUser = { name, address };
      setUsers([...users, newUser]);
    }

    setName("");
    setAddress("");
  };

  const handleEdit = (index) => {
    const userToEdit = users[index];
    setName(userToEdit.name);
    setAddress(userToEdit.address);
    setEditIndex(index);
  };

  const handleDelete = (index) => {
    const updatedUsers = users.filter((_, i) => i !== index);
    setUsers(updatedUsers);
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>User Management</h1>
      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.formGroup}>
          <label htmlFor="name" style={styles.label}>Name</label>
          <input
            type="text"
            id="name"
            placeholder="Enter your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            style={styles.input}
            required
          />
        </div>
        <div style={styles.formGroup}>
          <label htmlFor="address" style={styles.label}>Address</label>
          <input
            type="text"
            id="address"
            placeholder="Enter your address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            style={styles.input}
            required
          />
        </div>
        <button type="submit" style={styles.button}>
          {editIndex !== null ? "Update" : "Add"}
        </button>
      </form>
      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>Name</th>
            <th style={styles.th}>Address</th>
            <th style={styles.th}>Action</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={index}>
              <td style={styles.td}>{user.name}</td>
              <td style={styles.td}>{user.address}</td>
              <td style={styles.td}>
                <button onClick={() => handleEdit(index)} style={styles.editButton}>Edit</button>
                <button onClick={() => handleDelete(index)} style={styles.deleteButton}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default NewPage;

const styles = {
  container: {
    padding: "20px",
    maxWidth: "600px",
    margin: "0 auto",
    fontFamily: "Arial, sans-serif",
  },
  title: {
    textAlign: "center",
    marginBottom: "20px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    marginBottom: "20px",
  },
  formGroup: {
    marginBottom: "10px",
  },
  label: {
    marginBottom: "5px",
    fontWeight: "bold",
  },
  input: {
    padding: "8px",
    fontSize: "14px",
    borderRadius: "4px",
    border: "1px solid #ccc",
  },
  button: {
    padding: "10px 20px",
    fontSize: "16px",
    color: "#fff",
    backgroundColor: "#007bff",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    marginTop: "10px",
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
  },
  th: {
    padding: "8px",
    textAlign: "left",
    borderBottom: "1px solid #ddd",
  },
  td: {
    padding: "8px",
    borderBottom: "1px solid #ddd",
  },
  editButton: {
    padding: "5px 10px",
    fontSize: "14px",
    color: "#fff",
    backgroundColor: "#28a745",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    marginRight: "5px",
  },
  deleteButton: {
    padding: "5px 10px",
    fontSize: "14px",
    color: "#fff",
    backgroundColor: "#dc3545",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
  },
};

