import { configureStore } from '@reduxjs/toolkit';
import vikramslice from './vikramslice';


export const store = configureStore({
  reducer: {
    // customizer: CustomizerReducer,    
    vikramslice : vikramslice,
}});    

export default store;
