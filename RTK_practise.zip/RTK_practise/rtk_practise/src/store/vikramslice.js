import { API_HOST, POST_API } from "../base_URL/http";
import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import revertAll from "./action";

const initialState = {
  userLoginData: null,
  userLoginError: null,
};

export const loginslice = createSlice({
  name: "loginslice",
  initialState,
  reducers: {
    postGet: (state, action) => {
      state.userLoginData = action.payload;
    },
    postErrGet: (state, action) => {
      state.userLoginError = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(revertAll, () => initialState);
  },
});

export const GetLoginDetails = (Data) => async (dispatch) => {
  const localHeader = {};
  const bodyData = Data;
  try {
    const res = await axios({
      method: POST_API,
      url: API_HOST + `Account/Login`,
      headers: localHeader,
      data: bodyData, 
    });
    dispatch(postGet(res?.data));
  } catch (error) {
    dispatch(postErrGet(error?.response?.data?.Error?.Message));
    console.log("In get Login function error", error);
  }
};

export const { postGet, postErrGet } = loginslice.actions;
export default loginslice.reducer;
