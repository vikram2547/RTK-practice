import { createAction } from "@reduxjs/toolkit";

const revertAll = createAction("revertAll");

export default revertAll;
