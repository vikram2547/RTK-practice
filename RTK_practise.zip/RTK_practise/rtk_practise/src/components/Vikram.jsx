import React, { useState } from 'react';
import './Vikram.css'
import { useNavigate } from 'react-router-dom';

const Vikram = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');
  const [editingIndex, setEditingIndex] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!email || !password) {
      setError('Please fill in both email and password fields.');
      return;
    }
    setError('');
    if (editingIndex !== null) {
      // If editing, update the existing user
      const updatedUsers = [...users];
      updatedUsers[editingIndex] = { email, password };
      setUsers(updatedUsers);
      setEditingIndex(null);
    } else {
      // If not editing, add a new user
      const newUser = { email, password };
      setUsers([...users, newUser]);
    }
    setEmail('');
    setPassword('');
  };

  const handleDelete = (index) => {
    const updatedUsers = [...users];
    updatedUsers.splice(index, 1);
    setUsers(updatedUsers);
  };

  const handleEdit = (index) => {
    const userToEdit = users[index];
    setEmail(userToEdit.email);
    setPassword(userToEdit.password);
    setEditingIndex(index);
  };

  const nextPage = () => {
    navigate('/newPage');
  }

  return (
    <>
     <div>
      <button type='button' onClick={nextPage}>next page</button>
     </div>
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="add">{editingIndex !== null ? 'Update' : 'Add'}</button>
      </form>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {/* Table to display users */}
      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Email</th>
              <th>Password</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr key={index}>
                <td>{user.email}</td>
                <td>{user.password}</td>
                <td>
                  <button onClick={() => handleEdit(index)}>Edit</button>
                  <button onClick={() => handleDelete(index)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
    </>
  );
};

export default Vikram;
